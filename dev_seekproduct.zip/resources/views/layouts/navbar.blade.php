<header>
  <div class="container">
    <div class="row">
      <div class="col-md-3">
        <div class="logo">
          <a href="#">
            <img src="{{asset('img/logo.png')}}" align="">
          </a>
        </div>
        <div class="toggle_menu">
          <label>&#9776;</label>
        </div>
      </div>
      <div class="col-md-9">
        <nav>
          <ul>
            <li class="active"><a href="#">Home</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
            <li><a href="#">Log in</a></li>
            <li><a href="#">Register</a></li>
          </ul>
        </nav>
      </div>
      <div class="clearfix"></div>
    </div>
  </div>
</header>