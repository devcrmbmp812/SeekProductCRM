
@extends('layouts.app')
@section('content')
<div class="container">
	<h1>This is {{__('About')}} Page!</h1>

</div>
@endsection	