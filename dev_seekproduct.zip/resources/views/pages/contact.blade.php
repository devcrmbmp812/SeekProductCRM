@extends('layouts.app')

@section('content')
	<div class="container">
		<h1>This is {{__('Contact')}} Page.</h1>	
	</div>
@endsection